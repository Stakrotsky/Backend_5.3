const mongoose = require('mongoose');

const historySchema = new mongoose.Schema({
	userID: { type: String, required: true },
	testID: { type: mongoose.Schema.Types.ObjectId, ref: 'Test' },
	dateTaken: { type: Date, default: Date.now },
	correctAnswers: { type: Number, required: true },
	totalQuestions: { type: Number, required: true },
});

const History = mongoose.model('History', historySchema);
module.exports = History;
