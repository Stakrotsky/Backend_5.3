const express = require('express');
const History = require('../models/History');
const router = express.Router();

// Получить историю пользователя
router.get('/:userID', async (req, res) => {
	try {
		const history = await History.find({ userID: req.params.userID });
		res.json(history);
	} catch (error) {
		res.status(500).json({ message: error.message });
	}
});

// Сохранить результат
router.post('/', async (req, res) => {
	const history = new History({
		userID: req.body.userID,
		testID: req.body.testID,
		correctAnswers: req.body.correctAnswers,
		totalQuestions: req.body.totalQuestions,
	});

	try {
		const savedHistory = await history.save();
		res.status(201).json(savedHistory);
	} catch (error) {
		res.status(400).json({ message: error.message });
	}
});

module.exports = router;
