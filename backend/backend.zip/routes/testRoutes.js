const express = require('express');
const Test = require('../models/Test');
const testRouter = express.Router();

// Получение теста
testRouter.get('/test', async (req, res) => {
	try {
		const test = await Test.findOne();
		res.json(test);
	} catch (err) {
		res.status(500).send('Error fetching test');
	}
});
// Редактирование теста (например, добавление/удаление вопросов)
testRouter.put('/test', async (req, res) => {
	try {
		const { questions } = req.body;
		const test = await Test.findOne();

		test.questions = questions || test.questions;

		await test.save();
		res.json(test);
	} catch (err) {
		res.status(500).send('Error updating test');
	}
});

module.exports = testRouter;
