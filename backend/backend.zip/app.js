const express = require('express');
const mongoose = require('mongoose');
const testRoutes = require('./routes/testRoutes');

// Инициализация приложения Express
const app = express();
const port = 3001;

// Middleware
app.use(express.json());

app.use('/', testRoutes);

// Запуск сервера
mongoose
	.connect('mongodb+srv://stakrotsky:RsWAqS5ueibdLrKa@cluster0.7tzap.mongodb.net/quiz')
	.then(() => {
		app.listen(port, () => {
			console.log(`Server started on port ${port}`);
		});
	});
