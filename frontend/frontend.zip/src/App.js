import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HomePage from './pages/HomePage';
import TestPage from './pages/TestPage';
import ResultsPage from './pages/ResultsPage';

const App = () => {
	return (
		<Router>
			<Switch>
				<Route path="/" exact component={HomePage} />
				<Route path="/test/:id" component={TestPage} />
				<Route path="/results/:id" component={ResultsPage} />
			</Switch>
		</Router>
	);
};

export default App;
