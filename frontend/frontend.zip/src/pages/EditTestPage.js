import React, { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';

const EditTestPage = () => {
	const { id } = useParams(); // Получаем ID теста из URL
	const [test, setTest] = useState(null);
	const [isSaving, setIsSaving] = useState(false);
	const history = useHistory();

	useEffect(() => {
		// Загружаем тест с сервера для редактирования
		fetch(`http://localhost:5000/api/tests/${id}`)
			.then((response) => response.json())
			.then((data) => setTest(data));
	}, [id]);

	const handleQuestionChange = (index, field, value) => {
		const updatedTest = { ...test };
		updatedTest.questions[index][field] = value;
		setTest(updatedTest);
	};

	const handleAnswerChange = (questionIndex, answerIndex, value) => {
		const updatedTest = { ...test };
		updatedTest.questions[questionIndex].answers[answerIndex].answerText = value;
		setTest(updatedTest);
	};

	const addQuestion = () => {
		const updatedTest = { ...test };
		updatedTest.questions.push({
			questionText: '',
			answers: [{ answerText: '', isCorrect: false }],
		});
		setTest(updatedTest);
	};

	const removeQuestion = (index) => {
		const updatedTest = { ...test };
		updatedTest.questions.splice(index, 1);
		setTest(updatedTest);
	};

	const addAnswer = (questionIndex) => {
		const updatedTest = { ...test };
		updatedTest.questions[questionIndex].answers.push({
			answerText: '',
			isCorrect: false,
		});
		setTest(updatedTest);
	};

	const removeAnswer = (questionIndex, answerIndex) => {
		const updatedTest = { ...test };
		updatedTest.questions[questionIndex].answers.splice(answerIndex, 1);
		setTest(updatedTest);
	};

	const saveTest = () => {
		setIsSaving(true);

		fetch(`http://localhost:5000/api/tests/${id}`, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(test),
		})
			.then((response) => response.json())
			.then(() => {
				setIsSaving(false);
				history.push('/'); // Перенаправляем на главную страницу после сохранения
			})
			.catch(() => {
				setIsSaving(false);
				alert('Ошибка при сохранении теста');
			});
	};

	if (!test) return <div>Loading...</div>;

	return (
		<div>
			<h2>Редактирование теста</h2>
			<input
				type="text"
				value={test.title}
				onChange={(e) => handleQuestionChange(0, 'title', e.target.value)}
				placeholder="Название теста"
			/>
			<div>
				{test.questions.map((question, questionIndex) => (
					<div key={questionIndex}>
						<h3>Вопрос {questionIndex + 1}</h3>
						<input
							type="text"
							value={question.questionText}
							onChange={(e) =>
								handleQuestionChange(
									questionIndex,
									'questionText',
									e.target.value,
								)
							}
							placeholder="Текст вопроса"
						/>
						{question.answers.map((answer, answerIndex) => (
							<div key={answerIndex}>
								<input
									type="text"
									value={answer.answerText}
									onChange={(e) =>
										handleAnswerChange(
											questionIndex,
											answerIndex,
											e.target.value,
										)
									}
									placeholder="Текст ответа"
								/>
								<label>
									<input
										type="checkbox"
										checked={answer.isCorrect}
										onChange={() => {
											const updatedTest = { ...test };
											updatedTest.questions[questionIndex].answers[
												answerIndex
											].isCorrect =
												!updatedTest.questions[questionIndex]
													.answers[answerIndex].isCorrect;
											setTest(updatedTest);
										}}
									/>
									Правильный ответ
								</label>
								<button
									onClick={() =>
										removeAnswer(questionIndex, answerIndex)
									}
								>
									Удалить ответ
								</button>
							</div>
						))}
						<button onClick={() => addAnswer(questionIndex)}>
							Добавить вариант ответа
						</button>
						<button onClick={() => removeQuestion(questionIndex)}>
							Удалить вопрос
						</button>
					</div>
				))}
				<button onClick={addQuestion}>Добавить вопрос</button>
			</div>
			<button onClick={saveTest} disabled={isSaving}>
				{isSaving ? 'Сохранение...' : 'Сохранить'}
			</button>
			<button onClick={() => history.push('/')}>Отмена</button>
		</div>
	);
};

export default EditTestPage;
