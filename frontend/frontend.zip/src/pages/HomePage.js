import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getTests } from '../api/api';

const HomePage = () => {
	const [tests, setTests] = useState([]);
	const [history, setHistory] = useState([]);

	useEffect(() => {
		// Загружаем все тесты с сервера
		getTests().then((data) => setTests(data));

		// Загружаем историю из localStorage
		const userHistory = JSON.parse(localStorage.getItem('quizHistory')) || [];
		setHistory(userHistory);
	}, []);

	const startTest = () => {
		// Переход на страницу теста
	};

	const editTest = () => {
		// Переход на страницу редактирования теста
	};

	return (
		<div>
			<button onClick={startTest}>Запустить тест</button>
			<button onClick={editTest}>Редактировать тест</button>

			<h3>История прохождений</h3>
			<ul>
				{history.map((item, index) => (
					<li key={index}>
						<span>{item.date}</span> | Вопросов: {item.totalQuestions} |
						Верных ответов: {item.correctAnswers}
					</li>
				))}
			</ul>
		</div>
	);
};

export default HomePage;
