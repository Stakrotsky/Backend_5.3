import React, { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';

const TestPage = () => {
	const { id } = useParams(); // Получаем ID теста из URL
	const [test, setTest] = useState(null);
	const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
	const [answers, setAnswers] = useState([]);
	const history = useHistory();

	useEffect(() => {
		// Загружаем тест с сервера
		fetch(`http://localhost:5000/api/tests/${id}`)
			.then((response) => response.json())
			.then((data) => setTest(data));
	}, [id]);

	const handleAnswerSelect = (index) => {
		// Обновляем выбранный ответ для текущего вопроса
		const updatedAnswers = [...answers];
		updatedAnswers[currentQuestionIndex] = index;
		setAnswers(updatedAnswers);
	};

	const nextQuestion = () => {
		if (currentQuestionIndex < test.questions.length - 1) {
			setCurrentQuestionIndex(currentQuestionIndex + 1);
		}
	};

	const prevQuestion = () => {
		if (currentQuestionIndex > 0) {
			setCurrentQuestionIndex(currentQuestionIndex - 1);
		}
	};

	const finishTest = () => {
		// Вычисляем количество верных ответов и сохраняем в истории
		let correctAnswers = 0;
		test.questions.forEach((question, index) => {
			const selectedAnswerIndex = answers[index];
			if (question.answers[selectedAnswerIndex]?.isCorrect) {
				correctAnswers += 1;
			}
		});

		const historyData = {
			userID: 'user123', // Тут можно использовать ID текущего пользователя
			testID: id,
			correctAnswers,
			totalQuestions: test.questions.length,
		};

		// Сохраняем историю в localStorage
		let userHistory = JSON.parse(localStorage.getItem('quizHistory')) || [];
		userHistory.push(historyData);
		localStorage.setItem('quizHistory', JSON.stringify(userHistory));

		// Переход на страницу с результатами
		history.push(`/results/${id}`);
	};

	if (!test) return <div>Loading...</div>;

	return (
		<div>
			<h2>{test.title}</h2>
			<div>
				<p>{test.questions[currentQuestionIndex].questionText}</p>
				<ul>
					{test.questions[currentQuestionIndex].answers.map((answer, index) => (
						<li key={index}>
							<button onClick={() => handleAnswerSelect(index)}>
								{answer.answerText}
							</button>
						</li>
					))}
				</ul>
				<button onClick={prevQuestion} disabled={currentQuestionIndex === 0}>
					Предыдущий вопрос
				</button>
				<button
					onClick={nextQuestion}
					disabled={answers[currentQuestionIndex] === undefined}
				>
					Следующий вопрос
				</button>
				{currentQuestionIndex === test.questions.length - 1 && (
					<button onClick={finishTest}>Завершить тест</button>
				)}
			</div>
		</div>
	);
};

export default TestPage;
