import React, { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';

const ResultsPage = () => {
	const { id } = useParams(); // Получаем ID теста из URL
	const [result, setResult] = useState(null);
	const history = useHistory();

	useEffect(() => {
		// Здесь можно добавить логику, чтобы получить результат из localStorage или API
		const userHistory = JSON.parse(localStorage.getItem('quizHistory')) || [];
		const testResult = userHistory.find((item) => item.testID === id);

		if (testResult) {
			setResult(testResult);
		} else {
			history.push('/'); // Перенаправление на главную страницу, если результат не найден
		}
	}, [id, history]);

	if (!result) return <div>Loading...</div>;

	return (
		<div>
			<h2>Результаты теста</h2>
			<p>
				Правильных ответов: {result.correctAnswers} из {result.totalQuestions}
			</p>
			<button onClick={() => history.push('/')}>На главную</button>
			<button onClick={() => history.push(`/test/${id}`)}>Пройти еще раз</button>
		</div>
	);
};

export default ResultsPage;
